@extends('layouts.main')
@section('title')
@section('navMhs', 'active')

@section('content')
    <h1>Daftar Anggota</h1>
    
@endsection
