<footer class="bg-dark mt-auto py-3 text-white">
    <div class="container">
        <h2 class="text-center">Copyright &copy; {{ date("Y") }} PNP</h2>
    </div>
</footer>