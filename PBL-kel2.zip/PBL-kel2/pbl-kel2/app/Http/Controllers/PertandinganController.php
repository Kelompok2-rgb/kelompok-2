<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class PertandinganController extends Controller
{
    //
}
