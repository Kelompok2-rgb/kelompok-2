<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Hasil_Pertandingan extends Model
{
    //
}
