
<?php $__env->startSection('title'); ?>
<?php $__env->startSection('navMhs', 'active'); ?>

<?php $__env->startSection('content'); ?>
    <h1>Daftar Anggota</h1>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\PBL-kel2\pbl-kel2\resources\views/anggota/index.blade.php ENDPATH**/ ?>