<footer class="bg-dark mt-auto py-3 text-white">
    <div class="container">
        <h2 class="text-center">Copyright &copy; <?php echo e(date("Y")); ?> PNP</h2>
    </div>
</footer><?php /**PATH D:\PBL-kel2\pbl-kel2\resources\views/layouts/footer.blade.php ENDPATH**/ ?>